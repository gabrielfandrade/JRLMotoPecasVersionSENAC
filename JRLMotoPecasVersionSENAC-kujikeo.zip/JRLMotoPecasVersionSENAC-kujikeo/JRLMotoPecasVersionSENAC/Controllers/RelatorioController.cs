﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using JRLMotoPecasVersionSENAC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;

namespace JRLMotoPecasVersionSENAC.Controllers
{
    public class RelatorioController : Controller
    {

        private readonly JRLMotoPecasVersionSENACContext _context;

        public RelatorioController(JRLMotoPecasVersionSENACContext context)
        {
            _context = context;
        }


        public async Task<IActionResult> Relatorio(DateTime? dataInicial, DateTime? dataFinal)
        {
            
            List<Venda> Vendas = await _context.Venda.Where(i => i.Data_Compra >= dataInicial && i.Data_Compra <= dataFinal).Include(c => c.Id_Cliente).OrderBy(p => p.Data_Compra).ToListAsync<Venda>();

            return View(Vendas);

        }


        public async Task<IActionResult> Produtos(int? id)
        {

            if (id == null)
            {
                return NotFound();
            }

            Venda venda = await _context.Venda.FindAsync(id);

            venda.Produtos = await _context.ItemVenda.Where(i => i.Id == id).Include(p => p.IdProduto).ToListAsync<ItemVenda>();

            return View(venda);

        }
        // GET: Vendas
        public async Task<IActionResult> Index()
        {
            return View(await _context.Venda.Include(c => c.Id_Cliente).ToListAsync());
        }
        // GET: Vendas/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var venda = await _context.Venda
                .FirstOrDefaultAsync(m => m.Id == id);
            if (venda == null)
            {
                return NotFound();
            }

            return View(venda);
        }
        // GET: Vendas/Create
        public IActionResult Create()
        {
            return View();
        }

        // GET: Vendas/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var venda = await _context.Venda.FindAsync(id);
            if (venda == null)
            {
                return NotFound();
            }
            return View(venda);
        }
    }
}