﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JRLMotoPecasVersionSENAC.Models
{
    public class Endereco
    {

        public long Id { get; set; }
        public string Rua { get; set; }
        public string Complemento { get; set; }
        public string Bairro { get; set; }
        public int CEP { get; set; }
        //public string Cidade { get; set; }
        //public string Estado { get; set; }
        public int Numero { get; set; }
        public Cliente Cliente_id { get; set; }

        public Endereco()
        {

        }

        public Endereco(long id, string logradouro, string complemento, string bairro, int cEP, int numero, Cliente cliente_id)
        {
            Id = id;
            Rua = logradouro;
            Complemento = complemento;
            Bairro = bairro;
            CEP = cEP;
            Numero = numero;
            Cliente_id = cliente_id;
        }
    }
}
