﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JRLMotoPecasVersionSENAC.Models
{
    public class Produto
    {
        public long Id { get; set; }
        public string Nome { get; set; }
        public string Descricao { get; set; }
        //public string Categoria { get; set; }
        public int Quantidade { get; set; }
        public double Valor { get; set; }
        public byte[] Imagem { get; set; }
        public float Tamanho { get; set; }
        public string Cor { get; set; }
        public int tipo_da_moto { get; set; }
        
        public DateTime? Data_cadastro { get; set; }

        public Produto()
        {
            Data_cadastro = DateTime.Now;
        }

        public Produto(long id, string nome, string descricao,/* string categoria*/ int quantidade, double valor, byte[] imagem, float tamanho, string cor)
        {
            Id = id;
            Nome = nome;
            Descricao = descricao;
            //Categoria = categoria;
            Quantidade = quantidade;
            Valor = valor;
            Imagem = imagem;
            Tamanho = tamanho;
            Cor = cor;
        }
    }
}
