﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JRLMotoPecasVersionSENAC.Models
{
    public class Venda
    {
        
        public long Id { get; set; }
        public int Nota_fiscal { get; set; }
        public Cliente Id_Cliente { get; set; }
        public DateTime Data_Compra { get; set; }
        //public Double ValorEntrega { get; set; }
        public Endereco Endereco_id { get; set; }
        public double Valor_total { get; set; }
        //public string EstadoAtual { get; set; }
        public List<ItemVenda> Produtos { get; set; }

        public long Cartao_id { get; set; }
        public int Parcelas { get; set; }

        public Venda()
        {
        }

        public Venda(long id, int nota_fiscal, Cliente id_Cliente, DateTime data_Compra, Endereco endereco_id, double valor_total, List<ItemVenda> produtos, long cartao_id, int parcelas)
        {
            Id = id;
            Nota_fiscal = nota_fiscal;
            Id_Cliente = id_Cliente;
            Data_Compra = data_Compra;
            Endereco_id = endereco_id;
            Valor_total = valor_total;
            Produtos = produtos;
            Cartao_id = cartao_id;
            Parcelas = parcelas;
        }

        
    }
}
